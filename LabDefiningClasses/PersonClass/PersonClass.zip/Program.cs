﻿using System;
using System.Collections.Generic;

namespace PersonClass
{
   public class Program
    {
        static void Main(string[] args)
        {
            var acc = new BankAccount1();
            acc.Id = 1;
            acc.Balance = 100;



        }
           
            
        
    }
}
